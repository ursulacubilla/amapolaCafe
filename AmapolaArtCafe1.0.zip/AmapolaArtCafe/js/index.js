// JS formulario de reserva de mesa.
document.getElementById('form-contacto').addEventListener('submit', function(event) {
    event.preventDefault();
    
    var name = document.getElementById('nombre').value;
    var email = document.getElementById('email').value;
    var date = document.getElementById('fecha').value;
    var time = document.getElementById('hora').value;
    
    alert('¡Gracias por reservar, ' + name + '! Tu mesa está reservada para el ' + date + ' a las ' + time + '. Te esperamos.');

    document.getElementById('form-contacto').reset();
});

// Formulario de reserva de apsteles
